package hw1111;

public class ch3p28 {
    public static void main(String[] args) {
        Car car1 = new Car();
        car1.show();

        Car car2 = new Car(1234, 25.0);
        car2.show();
    }
}
