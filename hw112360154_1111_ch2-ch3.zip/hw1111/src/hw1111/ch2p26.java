package hw1111;

public class ch2p26 {
    public static void main(String[] args) {
        int i = 1;
        while(i <= 5) {
            System.out.println("第" + i + "次的迴圈");
            i++;
        }
        System.out.println("迴圈結束");
    }
}
