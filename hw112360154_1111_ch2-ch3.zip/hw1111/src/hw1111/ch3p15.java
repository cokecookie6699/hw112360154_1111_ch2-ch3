package hw1111;

public class ch3p15 {
    public static void main(String[] args) {
        Car car1;
        car1 = new Car();

        int number = 1234;
        double gasoline = 20.5;

        car1.setNumGas(number, gasoline);
    }
}
