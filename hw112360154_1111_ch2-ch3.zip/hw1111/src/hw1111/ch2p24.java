package hw1111;

public class ch2p24 {
    public static void main(String[] args) {
        for (int i = 1; i <= 5; i++) {
            System.out.println("第" + i + "次的迴圈");
        }
        System.out.println("迴圈結束");
    }
}
