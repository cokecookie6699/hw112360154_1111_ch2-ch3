package hw1111;

public class ch3p31 {
    public static void main(String[] args) {
        Car.showSum();

        Car car1 = new Car();
        car1.setCar(1234, 20.5);

        Car.showSum();

        Car car2 = new Car();
        car2.setCar(4567, 30.5);
    }
}
