package hw1111;

public class ch3p20 {
    public static void main(String[] args) {
        Car car1;
        car1 = new Car();

        car1.num = 1234;
        car1.gas = -10; // 錯誤的汽油量

        car1.show();
    }
}
