package hw1111;

public class ch3p5 {
    public static void main(String[] args) {
        Car car1;
        car1 = new Car();
    }
}