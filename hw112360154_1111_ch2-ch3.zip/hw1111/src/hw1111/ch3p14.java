package hw1111;

public class ch3p14 {
    public static void main(String[] args) {
        Car car1;
        car1 = new Car();

        car1.setNum(1234);
        car1.setGas(20.5);
    }
}
